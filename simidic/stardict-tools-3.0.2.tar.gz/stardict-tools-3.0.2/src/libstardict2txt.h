#ifndef _LIBSTARDICT2TXT_H_
#define _LIBSTARDICT2TXT_H_

#include "libcommon.h"

extern void convert_stardict2txt(const char *ifofilename, const char* txtfilename, print_info_t print_info);

#endif

