#ifndef _LIBTABFILE_H_
#define _LIBTABFILE_H_

#include "libcommon.h"

extern bool convert_tabfile(const char *filename, print_info_t print_info);

#endif
