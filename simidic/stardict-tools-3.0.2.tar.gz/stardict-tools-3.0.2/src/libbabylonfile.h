#ifndef _LIBBABYLONFILE_H_
#define _LIBBABYLONFILE_H_

#include "libcommon.h"

extern void convert_babylonfile(const char *filename, print_info_t print_info, bool strip_html);

#endif

