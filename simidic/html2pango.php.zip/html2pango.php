<?php
/************************************************************************
Program: html2pango.php
Author:  Amos B. Batto, email: amosbatto@yahoo.com
Licence: Public Domain
Project: Runasimipi Qespisqa Software, web: www.runasimipi.org
Created: 06 December 2012, (La Paz, Bolivia)

This script opens a dictionary TAB file and converts its HTML markup tags 
into Pango markup tags, so the dictionary can be used in StarDict which 
uses Pango (GTK+) markup. It produces a file named DICTIONARY-pango.tab.

To call this program:
   php html2pango.php DICTIONARY.tab
************************************************************************/
if ($argc < 2 or $argv[1] == "-h" or $argv[1] == "--help")
	exit("html2pango.php opens a dictionary TAB file and converts its HTML markup tags \n" .
		"into Pango markup tags, so the dictionary can be used in StarDict which \n" .
		"uses Pango (GTK+) markup. It produces a file named DICTIONARY-pango.tab.\n\n" .
		"To call this program: \n" .
		"php html2pango.php DICTIONARY.tab"
	);

$sFileIn = $argv[1];
$fparts = pathinfo($sFileIn);
$sFName = $fparts['filename'];
$sFilePango = $sFName . '-pango.tab';
$sDic = file_get_contents($sFileIn);

//convert <font color="..."> to <span foreground="...">
$sDicPango = preg_replace('/<font\s+color\s*=/i', '<span foreground=', $sDic);
$sDicPango = preg_replace('/<\/font>/i', '</span>', $sDicPango);
//convert <br> to \n
$sDicPango = preg_replace('/<br>/i', '\\n', $sDicPango);
//convert <strong> to <b>
$sDicPango = preg_replace('/<strong>/i', '<b>', $sDicPango);
$sDicPango = preg_replace('/<\/strong>/i', '</b>', $sDicPango);

//Convert green color to #228B22, which looks better in StarDict
$sDicPango = preg_replace('/="green">/i', '="#228B22">', $sDicPango);

//write altered content to the DICTIONARY-pango-tab file
file_put_contents($sFilePango, $sDicPango);
?>